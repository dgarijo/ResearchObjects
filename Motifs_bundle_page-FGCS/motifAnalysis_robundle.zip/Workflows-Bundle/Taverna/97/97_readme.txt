ID: 	97
TITLE: 	Download from ChemSpider using Accurate Mass
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/97/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/97/download/download_from_chemspider_using_accurate_mass_17623.xml
