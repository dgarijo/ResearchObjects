ID: 	2500
TITLE: 	BLASTP with simplified results returned
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2500/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2500/download/blastp_with_simplified_results_returned_171006.t2flow
