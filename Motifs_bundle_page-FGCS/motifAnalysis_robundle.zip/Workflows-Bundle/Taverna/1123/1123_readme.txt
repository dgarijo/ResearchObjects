ID: 	1123
TITLE: 	Compare two genomes for similarity
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1123/versions/4/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1123/download/_untitled__62323.t2flow
