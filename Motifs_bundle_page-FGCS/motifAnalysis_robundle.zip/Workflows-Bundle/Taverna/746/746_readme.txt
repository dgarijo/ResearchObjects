ID: 	746
TITLE: 	 Lymphoma type prediction based on microarray data 
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/746/versions/7/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/746/download/_lymphoma_type_prediction_based_on_microarray_data__547084.t2flow
