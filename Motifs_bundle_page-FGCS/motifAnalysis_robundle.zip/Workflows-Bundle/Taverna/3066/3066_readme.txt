ID: 	3066
TITLE: 	Run scripts from a column in a votable
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3066/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3066/download/run_scripts_from_a_column_in_a_votable_864.t2flow
