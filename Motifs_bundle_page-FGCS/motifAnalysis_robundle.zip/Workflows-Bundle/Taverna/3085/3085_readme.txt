ID: 	3085
TITLE: 	Gathering info from SDSS into a VOTable to execute Sextractor, Galfit and Ellipse.
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3085/versions/4/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3085/download/gathering_info_from_sdss_into_a_votable_to_execute_sextractor__galfit_and_ellipse._20888.t2flow
