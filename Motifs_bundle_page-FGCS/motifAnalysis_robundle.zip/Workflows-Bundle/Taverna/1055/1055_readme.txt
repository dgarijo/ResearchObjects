ID: 	1055
TITLE: 	Clean plain text
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1055/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1055/download/_untitled__545072.t2flow
