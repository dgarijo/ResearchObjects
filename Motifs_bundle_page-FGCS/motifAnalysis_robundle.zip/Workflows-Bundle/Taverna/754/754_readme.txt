ID: 	754
TITLE: 	Updated Biomart and Emboss workflow
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/754/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/754/download/updated_biomart_and_emboss_workflow_588842.t2flow
