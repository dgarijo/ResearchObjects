ID: 	2982
TITLE: 	Astronomical object name to equatorial coordinates Resolver
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2982/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2982/download/_untitled__364057.t2flow
