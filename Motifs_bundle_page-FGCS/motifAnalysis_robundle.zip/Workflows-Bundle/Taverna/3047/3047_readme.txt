ID: 	3047
TITLE: 	Create votable from sextractor results
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3047/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3047/download/create_votable_from_sextractor_results_668190.t2flow
