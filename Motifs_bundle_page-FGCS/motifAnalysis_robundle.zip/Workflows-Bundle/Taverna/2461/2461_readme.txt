ID: 	2461
TITLE: 	Extracting Quantities from HyperLEDA
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2461/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2461/download/extracting_quantities_from_hyperleda_197604.t2flow
