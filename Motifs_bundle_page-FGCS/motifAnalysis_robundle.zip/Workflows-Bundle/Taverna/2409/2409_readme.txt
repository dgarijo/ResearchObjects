ID: 	2409
TITLE: 	Comparing Quantities
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2409/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2409/download/comparing_quantities_261506.t2flow
