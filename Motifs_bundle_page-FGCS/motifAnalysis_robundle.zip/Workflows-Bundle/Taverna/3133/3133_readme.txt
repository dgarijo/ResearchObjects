ID: 	3133
TITLE: 	Get completion function V / Vm using the apparent magnitude list
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3133/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3133/download/get_completion_function_v___vm_using_the_apparent_magnitude_list_978018.t2flow
