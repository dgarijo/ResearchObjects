ID: 	2983
TITLE: 	VOTable of NED Images from a List of Objects
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2983/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2983/download/_untitled__560602.t2flow
