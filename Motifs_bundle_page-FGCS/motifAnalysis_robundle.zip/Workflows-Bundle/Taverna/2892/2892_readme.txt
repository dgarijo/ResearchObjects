ID: 	2892
TITLE: 	Example Diff WPS with 2 Raster Files
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2892/versions/4/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2892/download/example_diff_wps_with_2_raster_files_472658.t2flow
