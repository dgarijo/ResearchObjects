ID: 	2122
TITLE: 	Plotting distribution of natural product likeness scores
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2122/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2122/download/plotting_distribution_of_natural_product_likeness_scores_924981.t2flow
