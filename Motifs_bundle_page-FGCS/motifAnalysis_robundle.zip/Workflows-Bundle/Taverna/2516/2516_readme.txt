ID: 	2516
TITLE: 	date filter for ice Class Map service (NERSC)
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2516/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2516/download/date_filter_for_ice_class_map_service_976870.t2flow
