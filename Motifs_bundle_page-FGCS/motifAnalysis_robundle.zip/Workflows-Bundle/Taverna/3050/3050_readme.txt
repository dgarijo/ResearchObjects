ID: 	3050
TITLE: 	Create votable from galfit results 
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3050/versions/4/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3050/download/create_votable_from_galfit_results__681220.t2flow
