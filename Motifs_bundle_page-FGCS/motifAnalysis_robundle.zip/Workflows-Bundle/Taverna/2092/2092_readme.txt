ID: 	2092
TITLE: 	CGR from multiple fasta files
LICENSE TYPE: 	GPL
SVG PATH: 	http://www.myexperiment.org/workflows/2092/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2092/download/_untitled__431975.t2flow
