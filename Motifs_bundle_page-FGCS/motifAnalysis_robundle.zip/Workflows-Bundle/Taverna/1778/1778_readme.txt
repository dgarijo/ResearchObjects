ID: 	1778
TITLE: 	SELECT3
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/1778/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1778/download/select3_244566.t2flow
