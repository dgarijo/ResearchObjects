ID: 	3049
TITLE: 	Run galfit using a votable
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3049/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3049/download/run_galfit_using_a_votable_448798.t2flow
