ID: 	1054
TITLE: 	Clean plain text (ASCII)
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1054/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1054/download/_untitled__931468.t2flow
