ID: 	1903
TITLE: 	QSAR Descriptor Calculation Workflow
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1903/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1903/download/qsar_descriptor_calculation_workflow_552004.t2flow
