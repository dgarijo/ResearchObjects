ID: 	2773
TITLE: 	Darwin Core 2 CSV Shim Service
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2773/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2773/download/darwin_core_2_csv_shim_service_962754.t2flow
