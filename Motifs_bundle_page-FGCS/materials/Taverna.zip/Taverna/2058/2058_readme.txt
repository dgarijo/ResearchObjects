ID: 	2058
TITLE: 	Blast Report from ID
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2058/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2058/download/blast_report_from_id_867472.t2flow
