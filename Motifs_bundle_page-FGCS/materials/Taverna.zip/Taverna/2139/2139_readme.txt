ID: 	2139
TITLE: 	Download Structures from PubChem given chemical names
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2139/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2139/download/download_structures_from_pubchem_given_chemical_names_656742.t2flow
