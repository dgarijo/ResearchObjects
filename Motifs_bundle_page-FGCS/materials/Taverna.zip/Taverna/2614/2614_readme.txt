ID: 	2614
TITLE: 	Gathering galaxy properties using HyperLEDA
LICENSE TYPE: 	by-nc-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2614/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2614/download/gathering_galaxy_properties_using_hyperleda_129473.t2flow
