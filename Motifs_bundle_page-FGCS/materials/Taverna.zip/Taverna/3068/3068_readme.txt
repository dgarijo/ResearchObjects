ID: 	3068
TITLE: 	Calculate ellipses that describe a galaxy using iraf
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3068/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3068/download/calculate_ellipses_that_describe_a_galaxy_using_iraf_323295.t2flow
