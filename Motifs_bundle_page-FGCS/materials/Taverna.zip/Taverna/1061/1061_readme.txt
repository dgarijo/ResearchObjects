ID: 	1061
TITLE: 	Terms from collection of PDF files 
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1061/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1061/download/pdf_to_terms_with_c-value__453728.t2flow
