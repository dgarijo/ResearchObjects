ID: 	800
TITLE: 	G-language Genome Analysis Environment - Basic statistics on a numerical vector
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/800/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/800/download/g-language_genome_analysis_environment_-_basic_statistics_on_a_numerical_vector_374920.t2flow
