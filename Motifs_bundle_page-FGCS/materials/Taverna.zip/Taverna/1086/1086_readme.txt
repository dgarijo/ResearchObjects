ID: 	1086
TITLE: 	Transciption (DNA into RNA)
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/1086/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1086/download/transciption__dna--_gt_rna__483114.t2flow
