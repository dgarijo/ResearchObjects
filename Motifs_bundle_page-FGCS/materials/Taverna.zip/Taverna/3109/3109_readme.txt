ID: 	3109
TITLE: 	Create votable from different galfit paramenter adjustments
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3109/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3109/download/create_votable_from_different_galfit_paramenter_adjustments_684812.t2flow
