ID: 	2719
TITLE: 	Taxonomic Data Refinement Input Generator [v3]
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2719/versions/3/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2719/download/_untitled__852022.t2flow
