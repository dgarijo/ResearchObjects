ID: 	2686
TITLE: 	Pathways and Gene annotations forQTL region
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2686/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2686/download/pathways_and_gene_annotations_forqtl_region_521282.t2flow
