ID: 	1478
TITLE: 	caArray
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1478/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1478/download/caarray_458661.t2flow
