ID: 	3084
TITLE: 	Joining VOtables with information to execute Sextractor, Galfit and Ellipse.
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3084/versions/3/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3084/download/joining_votables_with_information_to_execute_sextractor__galfit_and_ellipse._20947.t2flow
