ID: 	3127
TITLE: 	Add columns to a votable resulting from executing sextractor.
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3127/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3127/download/add_columns_to_a_votable_resulting_from_executing_sextractor._338269.t2flow
