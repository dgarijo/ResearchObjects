ID: 	3130
TITLE: 	Cocatenates several VOTables into one
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3130/versions/3/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3130/download/cocatenates_several_votables_into_one_568019.t2flow
