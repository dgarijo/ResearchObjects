ID: 	2088
TITLE: 	PUT data into RapidAnalytics
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/2088/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2088/download/put_data_into_rapidanalytics_112163.t2flow
