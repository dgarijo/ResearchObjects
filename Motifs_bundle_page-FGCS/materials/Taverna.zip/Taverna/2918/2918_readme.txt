ID: 	2918
TITLE: 	Getting information from LEDA service
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2918/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2918/download/getting_information_from_leda_service_350994.t2flow
