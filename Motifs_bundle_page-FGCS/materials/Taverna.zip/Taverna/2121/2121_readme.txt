ID: 	2121
TITLE: 	Scoring small molecules for metabolite likeness/ Natural product likeness
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2121/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2121/download/_untitled__10216.t2flow
