ID: 	1470
TITLE: 	AUTOSTRUCTURE
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/1470/versions/4/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1470/download/autostructure_654039.t2flow
