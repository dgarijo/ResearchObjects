ID: 	2442
TITLE: 	Calculating galaxies distances using data from LEDA
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2442/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2442/download/calculating_galaxies_distances_using_data_from_leda_114663.t2flow
