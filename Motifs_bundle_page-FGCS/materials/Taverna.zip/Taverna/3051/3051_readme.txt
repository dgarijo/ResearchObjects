ID: 	3051
TITLE: 	Create galfit configuration files with partition criteria using votable
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3051/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3051/download/create_galfit_configuration_files_with_partition_criteria_using_votable_668606.t2flow
