ID: 	3054
TITLE: 	Extract SDSS field information and PSF
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3054/versions/5/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3054/download/extract_sdss_field_information_and_psf_127565.t2flow
