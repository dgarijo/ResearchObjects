ID: 	1058
TITLE: 	PDF to plain text
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1058/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1058/download/_untitled__840415.t2flow
