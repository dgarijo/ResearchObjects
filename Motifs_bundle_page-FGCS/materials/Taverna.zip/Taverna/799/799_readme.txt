ID: 	799
TITLE: 	G-language Genome Analysis Environment - Bacteria Analysis System
LICENSE TYPE: 	GPL
SVG PATH: 	http://www.myexperiment.org/workflows/799/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/799/download/g-language_genome_analysis_environment_-_bacteria_analysis_system_243354.t2flow
