ID: 	3012
TITLE: 	Example of how to use Sesame service and Virtual Observatory services
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3012/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3012/download/example_of_how_to_use_sesame_service_and_virtual_observatory_services_209885.t2flow
