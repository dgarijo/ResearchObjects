ID: 	1052
TITLE: 	LipidMaps Query
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1052/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1052/download/lipidmaps_query_819845.t2flow
