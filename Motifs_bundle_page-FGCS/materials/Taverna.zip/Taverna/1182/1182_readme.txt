ID: 	1182
TITLE: 	Extract proteins using a gi - output as fasta file 
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1182/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1182/download/extract_proteins_using_a_gi_-_output_as_fasta_file__885112.t2flow
