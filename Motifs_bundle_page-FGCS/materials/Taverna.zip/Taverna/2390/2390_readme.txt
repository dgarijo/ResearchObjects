ID: 	2390
TITLE: 	Name resolver of galaxies parsing the output using local services
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2390/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2390/download/name_resolver_of_galaxies_parsing_the_output_using_local_services_623160.t2flow
