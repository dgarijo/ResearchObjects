ID: 	1185
TITLE: 	Extract proteins from xml blast results
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/1185/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1185/download/extract_proteins_from_xml_blast_results_734375.t2flow
