ID: 	1857
TITLE: 	StRAnGER Web Service Workflow
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1857/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1857/download/_untitled__419884.t2flow
