ID: 	1990
TITLE: 	NCBI Gi to Kegg Pathways
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1990/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1990/download/ncbi_gi_to_kegg_pathways_966564.t2flow
