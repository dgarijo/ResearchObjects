ID: 	1238
TITLE: 	Genes encoded by KEGG pathway
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/1238/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1238/download/genes_encoded_by_kegg_pathway_264779.t2flow
