ID: 	1206
TITLE: 	XSTAR
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/1206/versions/3/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1206/download/xstar_828123.t2flow
