ID: 	3205
TITLE: 	Querying SDSS DR8 to get magnitude properties
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3205/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3205/download/extract_from_sloan_luminosity_data_924485.t2flow
