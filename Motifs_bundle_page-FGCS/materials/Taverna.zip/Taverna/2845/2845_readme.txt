ID: 	2845
TITLE: 	ENM native and 2050 workflow with interaction
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2845/versions/7/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2845/download/enm_native_and_2050_workflow_with_interaction_235474.t2flow
