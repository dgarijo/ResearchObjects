ID: 	2919
TITLE: 	Extract logr25 from LEDA service
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2919/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2919/download/extract_logr25_from_leda_service_530751.t2flow
