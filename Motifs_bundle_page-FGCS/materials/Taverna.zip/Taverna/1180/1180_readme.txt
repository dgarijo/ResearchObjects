ID: 	1180
TITLE: 	NCBI Gi to Kegg Pathways
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1180/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1180/download/ncbi_gi_to_kegg_pathways_217499.t2flow
