ID: 	1767
TITLE: 	EBI_InterproScan_NewServices
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1767/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1767/download/ebi_interproscan_newservices_421482.t2flow
